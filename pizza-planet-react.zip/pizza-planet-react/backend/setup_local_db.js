const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

async function setupDatabase() {
  console.log('🍕 Pizza Planet - Local Database Setup');
  console.log('---------------------------------------');
  
  const host = process.env.DB_HOST || 'localhost';
  const user = process.env.DB_USER || 'root';
  const password = process.env.DB_PASSWORD || 'your_password';
  const port = process.env.DB_PORT || 3306;

  console.log(`Connecting to MySQL at ${host}:${port} as user '${user}'...`);
  
  let connection;
  try {
    connection = await mysql.createConnection({
      host,
      user,
      password,
      port,
      multipleStatements: true // Required to run the entire schema.sql at once
    });
    console.log('✅ Connected to MySQL server successfully!');
  } catch (error) {
    console.error('❌ Failed to connect to MySQL server.');
    console.error('   Please ensure MySQL is installed, running, and the password in backend/.env is correct.');
    console.error('   Error details:', error.message);
    process.exit(1);
  }

  try {
    console.log('Reading database/schema.sql...');
    const schemaPath = path.join(__dirname, 'database', 'schema.sql');
    const schemaSql = fs.readFileSync(schemaPath, 'utf8');

    console.log('Executing schema script (creating database, tables, and seed data)...');
    await connection.query(schemaSql);
    
    console.log('✅ Database setup completed successfully!');
    console.log('   You can now start the backend with: npm start');
  } catch (error) {
    console.error('❌ Failed to execute schema script.');
    console.error('   Error details:', error.message);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

setupDatabase();
