import { useCallback, useEffect } from 'react';

const BELL_SOUND_URL = 'https://upload.wikimedia.org/wikipedia/commons/1/15/Bicycle_bell.wav';
let globalAudio = null;

export default function useDeviceNotification() {
  useEffect(() => {
    if (!globalAudio) {
      globalAudio = new Audio(BELL_SOUND_URL);
      globalAudio.preload = 'auto';
    }
  }, []);

  const notify = useCallback((title, options = {}) => {
    // 1. Play the HTML5 audio unconditionally
    if (globalAudio) {
      try {
        globalAudio.currentTime = 0;
        globalAudio.volume = 1;
        // The browser might block auto-play until interaction, 
        // but it will succeed on subsequent calls or if context is already active.
        const playPromise = globalAudio.play();
        if (playPromise !== undefined) {
          playPromise.catch(e => {
            // Silently handle autoplay restrictions (e.g. on first load)
            console.warn('Audio auto-play blocked by browser:', e);
          });
        }
      } catch (e) {
        console.warn('Audio play error:', e);
      }
    }

    // 2. Try OS notifications if permitted
    try {
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(title, { icon: '/favicon.ico', ...options });
      }
    } catch (e) {}
  }, []);

  return { notify };
}
