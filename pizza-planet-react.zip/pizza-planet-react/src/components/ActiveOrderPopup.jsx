import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import useDeviceNotification from '../hooks/useDeviceNotification';

export default function ActiveOrderPopup() {
  const [order, setOrder] = useState(null);
  const [activeOrderId, setActiveOrderId] = useState(localStorage.getItem('activeOrderId'));
  const prevStatus = useRef(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { notify } = useDeviceNotification();

  // Hide on order tracking page or admin page
  const isHidden = location.pathname.startsWith('/order') || location.pathname.startsWith('/admin');

  useEffect(() => {
    // Check localStorage periodically just in case it changes
    const checkStorage = () => {
      const stored = localStorage.getItem('activeOrderId');
      if (stored !== activeOrderId) {
        setActiveOrderId(stored);
        if (!stored) setOrder(null);
      }
    };
    const storageInterval = setInterval(checkStorage, 2000);
    return () => clearInterval(storageInterval);
  }, [activeOrderId]);

  useEffect(() => {
    if (!activeOrderId) return;
    
    let intervalId;

    const fetchOrder = async () => {
      try {
        const apiUrl = import.meta.env.VITE_API_URL ? import.meta.env.VITE_API_URL + '/orders/' + activeOrderId : 'http://localhost:5000/api/orders/' + activeOrderId;
        const res = await fetch(apiUrl);
        const data = await res.json();
        
        if (data.success) {
          setOrder(data.data);
          
          // Check if status changed
          if (prevStatus.current && prevStatus.current !== data.data.status) {
            notify(`Order Update: ${data.data.status.replace(/_/g, ' ')}`, {
              body: `Your order status has been updated to ${data.data.status.replace(/_/g, ' ')}`
            });
          }
          prevStatus.current = data.data.status;
        } else {
          // If order not found, maybe it was deleted
          localStorage.removeItem('activeOrderId');
          setActiveOrderId(null);
        }
      } catch (err) {
        // silently fail on polling
      }
    };

    fetchOrder();
    // Poll every 10 seconds
    intervalId = setInterval(fetchOrder, 10000);

    return () => clearInterval(intervalId);
  }, [activeOrderId, notify]);

  if (!order || isHidden) return null;

  const isDelivered = order.status === 'delivered' || order.status === 'cancelled';

  const statusColors = {
    pending: 'var(--color-warning)',
    confirmed: 'var(--color-info)',
    preparing: 'var(--color-primary)',
    ready: 'var(--color-success)',
    out_for_delivery: 'var(--color-secondary)',
    delivered: 'var(--color-success)',
    cancelled: 'var(--color-error)'
  };

  const handleDismiss = (e) => {
    e.stopPropagation();
    localStorage.removeItem('activeOrderId');
    setActiveOrderId(null);
    setOrder(null);
  };

  return (
    <div 
      onClick={() => navigate('/order/' + activeOrderId)}
      style={{
        position: 'fixed', bottom: '20px', left: '50%', transform: 'translateX(-50%)',
        width: 'calc(100% - 40px)', maxWidth: '500px', backgroundColor: 'var(--color-surface, #14141C)',
        border: '1px solid var(--color-border, #252532)', borderRadius: 'var(--radius-lg, 22px)',
        boxShadow: '0 10px 40px rgba(0,0,0,0.4)', zIndex: 999999, cursor: 'pointer',
        padding: '1.25rem 1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        color: '#fff'
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
        <div style={{ fontSize: '2.5rem', background: 'var(--color-bg-alt, #0D0D12)', width: '60px', height: '60px', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '50%', flexShrink: 0 }}>🛵</div>
        <div>
          <h4 style={{ margin: '0 0 0.25rem 0', fontSize: '1.1rem' }}>Order #{order?.order_number}</h4>
          <div style={{ fontSize: '0.875rem', fontWeight: 700, letterSpacing: '0.05em', color: statusColors[order?.status] || '#F06543' }}>
            Status: {order?.status ? order.status.replace(/_/g, ' ').toUpperCase() : 'UNKNOWN'}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#B8B5AF', marginTop: '2px' }}>
            Total: Rs {Number(order?.total || 0).toLocaleString()} · {order?.items?.length || 0} items
          </div>
        </div>
      </div>
      
      {isDelivered && (
        <button 
          onClick={handleDismiss}
          style={{ background: '#0D0D12', border: '1px solid #252532', color: '#fff', padding: '0.5rem 1rem', borderRadius: '8px', fontSize: '0.75rem', fontWeight: 600, cursor: 'pointer' }}
        >
          ✕ Dismiss
        </button>
      )}
    </div>
  );
}
