# 🍕 Pizza Planet — Full Stack Food Ordering Website

React.js frontend + Node.js/Express backend + MySQL database.

---

## 🚀 Quick Start (How to run this daily on your PC)
If the database and project are already set up on this computer, you just need to start the two servers.

**1. Start the Backend:**
Open a terminal in the `backend` folder and run:
```bash
npm start
```
*(Keep this terminal open. It runs the API on port 5000)*

**2. Start the Frontend:**
Open a second terminal in the main `pizza-planet-react` folder and run:
```bash
npm run dev
```
*(Keep this terminal open. It runs the website on port 5173. Open `http://localhost:5173` in your browser)*

---

## 🛠️ Fresh Installation Guide (For a Friend's PC / New Computer)
If you are moving this folder to a brand new computer (like your client's PC), you must follow these exact steps from start to finish.

### Step 1: Install Prerequisites
1. **Install Node.js:** Download and install from [nodejs.org](https://nodejs.org/).
2. **Install MySQL:** Download and install [MySQL Community Server](https://dev.mysql.com/downloads/installer/).
   - *IMPORTANT:* During installation, it will ask you to set a `root` password. Write this password down!

### Step 2: Configure the Database Connection
1. Inside the project, open the file `backend/.env`.
2. Find the line that says `DB_PASSWORD=root` (or whatever it currently is).
3. Change it to the **exact password** you created when installing MySQL on this new PC.
   *(Leave DB_HOST as `localhost` and DB_USER as `root`)*.

### Step 3: Auto-Setup the Database (One-time only)
1. Open a terminal inside the `backend` folder.
2. Install the backend dependencies by running:
   ```bash
   npm install
   ```
3. Run the automatic database setup script:
   ```bash
   npm run setup-db
   ```
   *(This script will automatically log into MySQL, create the `pizza_planet` database, build all the tables, and insert the menu items and admin user!)*

### Step 4: Install Frontend Dependencies (One-time only)
1. Open a terminal in the main `pizza-planet-react` folder.
2. Install the frontend dependencies by running:
   ```bash
   npm install
   ```

### Step 5: Start the Servers
Now you can follow the **Quick Start** instructions at the top of this file to run `npm start` in the backend and `npm run dev` in the frontend!

---

## 👑 Admin Panel Credentials
To log in to the admin dashboard and manage orders, go to `/admin` on the website and use:
- **Email:** `admin@pizzaplanet.com`
- **Password:** `admin123`

---

## Project Structure
```
pizza-planet-react/
├── package.json            # Frontend dependencies
├── src/                    # React Frontend Code
│   ├── components/         # UI Components (Popup, Cart, Header, etc.)
│   ├── contexts/           # State Management (Cart, Auth, etc.)
│   └── styles/             # CSS Files
└── backend/                # Node.js/Express Backend Code
    ├── server.js           # API Server
    ├── .env                # Database configuration
    └── database/           
        ├── schema.sql      # Database structure & data
        └── setup.js        # Auto-setup script
```

## Features Included
- **Floating Order Tracker:** Tracks real-time order status via a floating popup on the homepage.
- **Audio Notifications:** Rings automatically on the customer's device when the admin updates their order status.
- **Complete Cart System:** Real-time cart calculations, delivery fee thresholds, and checkout logic.
- **Admin Dashboard:** Manage incoming orders and change status (Pending -> Confirmed -> Preparing -> Delivered).
